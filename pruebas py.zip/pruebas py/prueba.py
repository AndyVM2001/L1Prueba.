import time
import os
import pymysql
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
import pandas as pd
from sqlalchemy import create_engine

# Configuración de la conexión a MySQL
host = 'localhost'
user = 'root'
password = ''
database = 'cargadatos'
port = 3306

# Conexión al servidor MySQL
connection = pymysql.connect(host=host, user=user, password=password, port=port)

# Creación de la base de datos si no existe
try:
    with connection.cursor() as cursor:
        cursor.execute(f"CREATE DATABASE IF NOT EXISTS {database}")
    connection.commit()
finally:
    connection.close()

# Conexión a la base de datos volcodata
cadena_conexion = f'mysql+pymysql://{user}:{password}@{host}:{port}/{database}'
motor_db = create_engine(cadena_conexion)

# Ruta de la carpeta a monitorear
ruta_carpeta = 'C:/Users/ANDY J VERA M/OneDrive/REPORTES IMPUESTOS'


class ManejadorEventos(FileSystemEventHandler):
    def on_created(self, event):
        if event.is_directory:
            return
        elif event.src_path.endswith('.xlsx') or event.src_path.endswith('.xls'):
            print(f"Nuevo archivo detectado: {event.src_path}")
            try:
                # Leer el archivo Excel y volcar los datos a la base de datos SQL
                df = pd.read_excel(event.src_path)
                nombre_tabla = os.path.splitext(os.path.basename(event.src_path))[0]
                df.to_sql(nombre_tabla, motor_db, if_exists='replace', index=False)
                print(f"Datos del archivo {event.src_path} volcados a la tabla {nombre_tabla} en la base de datos.")
                print("Los archivos han sido cargados correctamente.")
            except Exception as e:
                print(f"Error al procesar el archivo {event.src_path}: {str(e)}")

if __name__ == "__main__":
    print("Iniciando monitoreo de la carpeta...")
    event_handler = ManejadorEventos()
    observer = Observer()
    observer.schedule(event_handler, ruta_carpeta, recursive=False)
    observer.start()

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
        observer.join()


